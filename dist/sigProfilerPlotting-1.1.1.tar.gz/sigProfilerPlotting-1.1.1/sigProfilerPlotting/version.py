
# THIS FILE IS GENERATED FROM SIGPROFILERPLOTTING SETUP.PY
short_version = '1.1.1'
version = '1.1.1'
    
    