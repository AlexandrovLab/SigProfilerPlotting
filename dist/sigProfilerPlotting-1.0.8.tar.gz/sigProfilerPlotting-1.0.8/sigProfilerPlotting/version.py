
# THIS FILE IS GENERATED FROM SIGPROFILERPLOTTING SETUP.PY
short_version = '1.0.8'
version = '1.0.8'
    
    