
# THIS FILE IS GENERATED FROM SIGPROFILERPLOTTING SETUP.PY
short_version = '1.0.2'
version = '1.0.2'
    
    