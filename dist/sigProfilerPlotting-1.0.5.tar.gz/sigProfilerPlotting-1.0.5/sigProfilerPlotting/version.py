
# THIS FILE IS GENERATED FROM SIGPROFILERPLOTTING SETUP.PY
short_version = '1.0.5'
version = '1.0.5'
    
    